from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, generics

from picker.models import Product, QuizSubmission
from picker.services.scoring import score_products

from .serializers import (
    ProductSerializer,
    QuizSubmitSerializer,
)
from ..data.quiz_questions import QUIZ_QUESTIONS


class ProductListAPIView(generics.ListAPIView):
    serializer_class = ProductSerializer

    def get_queryset(self):
        queryset = Product.objects.filter(is_active=True)

        product_type = self.request.query_params.get("type")
        role = self.request.query_params.get("role")
        budget = self.request.query_params.get("budget")

        if product_type:
            queryset = queryset.filter(type=product_type)

        if budget:
            queryset = queryset.filter(budget_tier=budget)

        if role:
            queryset = queryset.filter(roles__contains=[role])

        return queryset


class ProductDetailAPIView(generics.RetrieveAPIView):
    serializer_class = ProductSerializer
    queryset = Product.objects.filter(is_active=True)
    lookup_field = "slug"


class QuizSubmitAPIView(APIView):
    def post(self, request):
        serializer = QuizSubmitSerializer(data=request.data)

        serializer.is_valid(raise_exception=True)

        answers = serializer.validated_data

        products = Product.objects.filter(
            is_active=True
        )

        results = score_products(
            products=products,
            answers=answers,
            top_n=3,
        )

        response_results = []

        for item in results:
            product = item["product"]

            response_results.append({
                "slug": product.slug,
                "name": product.name,
                "type": product.type,
                "summary": product.summary,
                "image": (
                    request.build_absolute_uri(product.image.url)
                    if product.image
                    else None
                ),
                "score": item["score"],
                "match_percent": item["match_percent"],
            })

        submission = QuizSubmission.objects.create(
            answers=answers,
            results=response_results,
        )

        return Response(
            {
                "submission_id": submission.id,
                "results": response_results,
            },
            status=status.HTTP_200_OK,
        )


class QuizQuestionsAPIView(APIView):
    def get(self, request):
        return Response(
            {
                "questions": QUIZ_QUESTIONS
            }
        )


class SubmissionDetailAPIView(APIView):
    def get(self, request, pk):
        submission = get_object_or_404(
            QuizSubmission,
            pk=pk,
        )

        return Response(
            {
                "id": submission.id,
                "answers": submission.answers,
                "results": submission.results,
                "created_at": submission.created_at,
            }
        )


class FiltersAPIView(APIView):
    def get(self, request):
        return Response(
            {
                "types": [
                    "AEG",
                    "GBBR",
                    "HPA",
                    "Spring",
                    "GBB",
                ],
                "budgets": [
                    "low",
                    "medium",
                    "high",
                ],
                "roles": [
                    "cqb",
                    "forest",
                    "field",
                    "milsim",
                ],
            }
        )


class HealthAPIView(APIView):
    def get(self, request):
        return Response(
            {
                "status": "ok"
            }
        )